SMART AI — PROYEK APLIKASI ANDROID
=================================

Yang disertakan:
- Aplikasi Android sederhana berbasis WebView dengan nama SMART AI.
- Tampilan SMART AI disimpan lokal di dalam aplikasi, jadi halaman utamanya dapat dibuka tanpa hosting.
- Pemilih foto Android untuk fitur Scan.
- Tombol pembuat Google Form dapat menyimpan file buat-google-form.gs ke lokasi yang dipilih.
- Workflow GitHub Actions untuk membangun APK debug secara otomatis.

PENTING — BATASAN FITUR
- Ini mengemas prototipe sebelumnya menjadi kerangka aplikasi Android. Chat masih demo dan belum terhubung ke model AI.
- Scan foto hanya menampilkan pratinjau; OCR/pembacaan soal belum diaktifkan.
- Pembuat Google Form menyiapkan script Google Apps Script. Script dijalankan sendiri di script.google.com dengan akun Google pengguna untuk membuat Form asli.
- Aplikasi tidak meminta password Google. Jangan berikan password kepada aplikasi lain.

CARA MENDAPATKAN APK DENGAN GITHUB ACTIONS (bisa lewat HP):
1. Ekstrak ZIP ini di HP.
2. Masuk ke github.com dan buat repository baru bernama SMART-AI (akun GitHub diperlukan).
3. Buka repository, pilih Add file > Upload files, lalu unggah semua isi folder proyek (termasuk folder .github). Pastikan file settings.gradle dan build.gradle berada di bagian paling atas repository, bukan di dalam folder tambahan.
4. Commit/upload. Buka tab Actions dan pilih workflow "Build SMART AI APK". Jika belum berjalan otomatis, tekan Run workflow.
5. Setelah status build hijau/success, buka hasil workflow dan unduh artifact bernama SMART-AI-APK.
6. Ekstrak artifact ZIP, lalu buka app-debug.apk untuk memasang. Android mungkin meminta izin memasang aplikasi dari sumber tersebut.

Catatan teknis:
- APK debug dibuat dan ditandatangani otomatis oleh Gradle untuk pengujian/pemasangan pribadi.
- Untuk distribusi publik/Play Store, aplikasi memerlukan proses signing rilis dan pemeriksaan tambahan.
- Proyek menggunakan Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, dan Android SDK 35.
